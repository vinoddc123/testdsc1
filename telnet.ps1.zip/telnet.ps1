Configuration telnet

    {param ($servername)
node $servername
  
      {
        windowsfeature WDS
        {
          Name = 'wds'
          Ensure ='present'
          Includeallsubfeature = $true
        }
   }
 
}