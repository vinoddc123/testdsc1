Configuration Webserver
{
  param ($NodeName)

  Node $NodeName
  {
    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure = �Present�
      Name = �Web-Server�
    }

    #Install ASP.NET 4.5
    WindowsFeature ASP
    {
      Ensure = �Present�
      Name = �Web-Asp-Net45�
    }

     WindowsFeature WebServerManagementConsole
    {
        Name = "Web-Mgmt-Console"
        Ensure = "Present"
    }

    Script IISTEST
    {
        TestScript = {
            Test-Path "C:\inetpub\wwwroot\index.html"
        }
        SetScript ={
            
            New-Item     C:\inetpub\wwwroot -ItemType Directory -Force

            "<html>
            <head>
            <title>IISTest!</title>
            </head>
            <body>
            Test website!<br><br>
            <b></b> 
            </body>
            </html>" | Out-File "C:\inetpub\wwwroot\index.html" -Force
             
        }
        GetScript = {@{Result = "HelloWorld"}}
        DependsOn = "[WindowsFeature]IIS"
    }
  }
} 