Configuration Webserver
{
  param ($servername)

  Node localhost 
  {
    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure = �Present�
      Name = �Web-Server�
    }

    #Install ASP.NET 4.5
    WindowsFeature ASP
    {
      Ensure = �Present�
      Name = �Web-Asp-Net45�
    }

     WindowsFeature WebServerManagementConsole
    {
        Name = "Web-Mgmt-Console"
        Ensure = "Present"
    }

    Script testsite

    {
        TestScript = {
            Test-Path "C:\inetpub\wwwroot\index.html"
        }
        SetScript ={
            
            New-Item     C:\inetpub\wwwroot -ItemType Directory -Force

            "<html>
            <head>
            <title>Hello World!</title>
            </head>
            <body>
            Testsite!<br><br>
            <b>Hostname:</b> 
            </body>
            </html>" | Out-File "C:\inetpub\wwwroot\index.html" -Force
             
        }
        GetScript = {@{Result = "Testsite"}}
        DependsOn = "[WindowsFeature]IIS"
    }
  }
} 